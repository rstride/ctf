from flask import Flask, render_template, send_from_directory
from flask_socketio import SocketIO, emit
import json
import argparse
import pty
import os
import subprocess
import select
import termios
import struct
import fcntl
import shlex
import logging
import sys
import time
import threading
import socket 

logging.getLogger("werkzeug").setLevel(logging.ERROR)

__version__ = "0.5.0.2"

app = Flask(__name__)
app.config["SECRET_KEY"] = "secret!"
app.config["fd"] = None
app.config["child_pid"] = None

socketio = SocketIO(app)

porte_ouverte = False
UDP_IP = "192.168.3.10"  # IP locale
UDP_PORT = 4444

# Tilemap watching variables
tilemap_path = 'static/data/tilemap.json'
last_modified_time = 0

def set_winsize(fd, row, col, xpix=0, ypix=0):
    logging.debug("setting window size with termios")
    winsize = struct.pack("HHHH", row, col, xpix, ypix)
    fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)

def read_and_forward_pty_output():
    max_read_bytes = 1024 * 20
    while True:
        socketio.sleep(0.01)
        if app.config["fd"]:
            timeout_sec = 0
            (data_ready, _, _) = select.select([app.config["fd"]], [], [], timeout_sec)
            if data_ready:
                output = os.read(app.config["fd"], max_read_bytes).decode(errors="ignore")
                socketio.emit("pty-output", {"output": output}, namespace="/pty")

@app.route("/")
def hello():
    return render_template('Machine.html', titre="TIM2024")


@app.route("/platformer")
def platformer():
    return render_template('platformer.html', titre="platformer")

@app.route("/term")
def index():
    return render_template("index.html")

@socketio.on("pty-input", namespace="/pty")
def pty_input(data):
    if app.config["fd"]:
        logging.debug("received input from browser: %s" % data["input"])
        os.write(app.config["fd"], data["input"].encode())

@socketio.on("resize", namespace="/pty")
def resize(data):
    if app.config["fd"]:
        logging.debug(f"Resizing window to {data['rows']}x{data['cols']}")
        set_winsize(app.config["fd"], data["rows"], data["cols"])

@socketio.on("connect", namespace="/pty")
def connect():
    logging.info("new client connected")
    if app.config["child_pid"]:
        return

    (child_pid, fd) = pty.fork()
    if child_pid == 0:
        subprocess.run(app.config["cmd"])
    else:
        app.config["fd"] = fd
        app.config["child_pid"] = child_pid
        set_winsize(fd, 50, 50)
        cmd = " ".join(shlex.quote(c) for c in app.config["cmd"])
        socketio.start_background_task(target=read_and_forward_pty_output)
        logging.info(f"child pid is {child_pid}")
        logging.info(f"starting background task with command `{cmd}`")

@socketio.on('request_update')
def handle_update_request():
    emit_tilemap_update()

@app.route('/static/data/tilemap.json')
def serve_tilemap():
    return send_from_directory('static/data', 'tilemap.json')

def load_tilemap():
    global last_modified_time
    current_time = os.path.getmtime(tilemap_path)
    if current_time > last_modified_time:
        with open(tilemap_path, 'r') as f:
            tilemap_data = json.load(f)
        last_modified_time = current_time
        return tilemap_data
    return None

def emit_tilemap_update():
    tilemap_data = load_tilemap()
    if tilemap_data:
        socketio.emit('tilemap_update', tilemap_data)

def check_tilemap_updates():
    while True:
        tilemap_data = load_tilemap()
        if tilemap_data:
            socketio.emit('tilemap_update', tilemap_data)
        socketio.sleep(1)  # Check every second

# ------------------ Ajout du serveur UDP ------------------
# Fonction pour copier les fichiers JSON
def copy_json_files(src_file, dst_file):
    try:
        with open(src_file, 'r') as source:
            data = json.load(source)
        
        with open(dst_file, 'w') as destination:
            json.dump(data, destination, indent=2)
        
        print(f"Contenu copié de {src_file} vers {dst_file}")
    except Exception as e:
        print(f"Erreur lors de la copie du fichier : {e}")

# Fonction pour fermer la porte après 10 secondes
def fermer_porte_automatiquement(sock, addr, src_close, dst_tilemap):
    global porte_ouverte
    print("La porte se fermera dans 10 secondes...")
    time.sleep(10)
    
    if porte_ouverte:  # Si la porte est encore ouverte après 10 secondes
        porte_ouverte = False
        copy_json_files(src_close, dst_tilemap)
        print("Porte fermée automatiquement après 10 secondes.")
        envoyer_reponse_udp(sock, addr, "Porte fermée automatiquement.\n")

# Fonction pour envoyer une réponse UDP avec un retour à la ligne
def envoyer_reponse_udp(sock, addr, message):
    sock.sendto((message + "\n").encode(), addr)  # Ajout d'un retour à la ligne
    print(f"Réponse envoyée à {addr}: {message}")

# Serveur UDP
def start_udp_server():
    global porte_ouverte
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((UDP_IP, UDP_PORT))

    print(f"En attente de données UDP sur {UDP_IP}:{UDP_PORT}")

    # Chemins des fichiers
    src_open = '/home/noghost/dev/loSt/static/data/ouvert.json'
    src_close = '/home/noghost/dev/loSt/static/data/ferme.json'
    dst_tilemap = '/home/noghost/dev/loSt/static/data/tilemap.json'

    while True:
        data, addr = sock.recvfrom(1024)
        message = data.decode().strip().lower()
        print(f"Message reçu de {addr}: {message}")
        
        if message == "open":
            if not porte_ouverte:
                print("Message 'open' reçu. Ouverture de la porte...")
                copy_json_files(src_open, dst_tilemap)
                porte_ouverte = True
                envoyer_reponse_udp(sock, addr, "Porte ouverte.")
                
                # Démarrer un thread pour fermer la porte après 10 secondes
                threading.Thread(target=fermer_porte_automatiquement, args=(sock, addr, src_close, dst_tilemap), daemon=True).start()
            else:
                print("La porte est déjà ouverte.")
                envoyer_reponse_udp(sock, addr, "Porte déjà ouverte.")

        elif message == "close":
            if porte_ouverte:
                porte_ouverte = False
                print("Message 'close' reçu. Fermeture de la porte...")
                copy_json_files(src_close, dst_tilemap)
                envoyer_reponse_udp(sock, addr, "Porte fermée.")
            else:
                print("La porte est déjà fermée.")
                envoyer_reponse_udp(sock, addr, "Porte déjà fermée.")

        elif message == "?":
            etat = "ouverte" if porte_ouverte else "fermée"
            print(f"État actuel : {etat}.")
            envoyer_reponse_udp(sock, addr, f"Porte {etat}.")
        
        else:
            print(f"Message non reconnu : {message}")
            envoyer_reponse_udp(sock, addr, "Commande non reconnue. Utilisez 'open', 'close', ou '?'.")

# ----------------------------------------------------------
def start_udp_background_task():
    thread = threading.Thread(target=start_udp_server, daemon=True)
    thread.start()
    print("Serveur UDP démarré en tâche de fond.")

def main():
    parser = argparse.ArgumentParser(
        description="A fully functional terminal in your browser with tilemap updates.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("-p", "--port", default=5000, help="port to run server on", type=int)
    parser.add_argument("--host", default="192.168.3.10", help="host to run server on")
    parser.add_argument("--debug", action="store_true", help="debug the server")
    parser.add_argument("--version", action="store_true", help="print version and exit")
    parser.add_argument("--command", default="bash", help="Command to run in the terminal")
    parser.add_argument("--cmd-args", default="", help="arguments to pass to command")
    
    args = parser.parse_args()
    if args.version:
        print(__version__)
        exit(0)
    
    app.config["cmd"] = [args.command] + shlex.split(args.cmd_args)
    
    log_format = "\033[92mpyxtermjs >\033[0m %(levelname)s (%(funcName)s:%(lineno)s) %(message)s"
    logging.basicConfig(
        format=log_format,
        stream=sys.stdout,
        level=logging.DEBUG if args.debug else logging.INFO,
    )
    logging.info(f"serving on http://{args.host}:{args.port}")

    start_udp_background_task()

    socketio.start_background_task(check_tilemap_updates)
    socketio.run(app, debug=args.debug, port=args.port, host=args.host)

if __name__ == "__main__":
    main()
